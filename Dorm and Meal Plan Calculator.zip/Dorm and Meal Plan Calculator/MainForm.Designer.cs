﻿namespace Dorm_and_Meal_Plan_Calculator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.selectButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.lstDorms = new System.Windows.Forms.ListBox();
            this.lstMealPlans = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // selectButton
            // 
            this.selectButton.Location = new System.Drawing.Point(135, 182);
            this.selectButton.Name = "selectButton";
            this.selectButton.Size = new System.Drawing.Size(75, 23);
            this.selectButton.TabIndex = 0;
            this.selectButton.Text = "Select";
            this.selectButton.UseVisualStyleBackColor = true;
            this.selectButton.Click += new System.EventHandler(this.selectButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(227, 182);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 1;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // lstDorms
            // 
            this.lstDorms.FormattingEnabled = true;
            this.lstDorms.Location = new System.Drawing.Point(28, 17);
            this.lstDorms.Name = "lstDorms";
            this.lstDorms.Size = new System.Drawing.Size(181, 134);
            this.lstDorms.TabIndex = 2;
            // 
            // lstMealPlans
            // 
            this.lstMealPlans.FormattingEnabled = true;
            this.lstMealPlans.Location = new System.Drawing.Point(227, 17);
            this.lstMealPlans.Name = "lstMealPlans";
            this.lstMealPlans.Size = new System.Drawing.Size(190, 134);
            this.lstMealPlans.TabIndex = 3;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 218);
            this.Controls.Add(this.lstMealPlans);
            this.Controls.Add(this.lstDorms);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.selectButton);
            this.Name = "MainForm";
            this.Text = "Dormitories and Meal Plans ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button selectButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.ListBox lstDorms;
        private System.Windows.Forms.ListBox lstMealPlans;
    }
}

