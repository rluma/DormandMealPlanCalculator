﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dorm_and_Meal_Plan_Calculator
{
    public partial class MainForm : Form
    {
        private Dormitory[] dormitories = {
        new Dormitory("Allen Hall", 1500m),
        new Dormitory("Pike Hall", 1600m),
        new Dormitory("Farthing Hall", 1800m),
        new Dormitory("University Suites", 2500m),
        };

        private MealPlan[] mealPlans = {
        new MealPlan("7 meals per week", 600m),
        new MealPlan("14 meals per week", 1200m),
        new MealPlan("Unlimited meals", 1700m),
        };

        public MainForm()
        {
            InitializeComponent();

            foreach (var dormitory in dormitories)
            {
                lstDorms.Items.Add(dormitory.Name);
            }

            foreach (var mealPlan in mealPlans)
            {
                lstMealPlans.Items.Add(mealPlan.Name);
            }
        }

        private void selectButton_Click(object sender, EventArgs e)
        {
            var selectedDormitory = dormitories[lstDorms.SelectedIndex];
            var selectedMealPlan = mealPlans[lstMealPlans.SelectedIndex];
            var resultsForm = new ResultsForm(selectedDormitory, selectedMealPlan);
            resultsForm.ShowDialog();
        }
  
        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}